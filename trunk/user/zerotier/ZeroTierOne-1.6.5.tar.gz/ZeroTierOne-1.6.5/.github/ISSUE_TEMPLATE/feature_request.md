---
name: Feature request
about: Suggest an idea for this project
title: "[Feature Request] "
labels: suggestion
assignees: ''

---

If there is something you'd like to have added to ZeroTier, to go to https://discuss.zerotier.com/c/feature-requests/ instead. Issues there can be voted on and discussed in-depth.


Thank you!
